package com.evalenzuela.navigation.data.repository

import com.evalenzuela.navigation.data.model.Item
import kotlinx.coroutines.delay

class SampleRepository {

    private val sampleItems = listOf(
        Item(1, "Laptop Gamer", "Alto rendimiento para gaming y desarrollo.", "$1.299.990"),
        Item(2, "Monitor Curvo 27\"", "Ideal para diseño gráfico y programación.", "$349.500"),
        Item(3, "Teclado Mecánico", "Switches rojos silenciosos y retroiluminación RGB.", "$89.990"),
        Item(4, "Mouse Inalámbrico", "Ergonómico, 16000 DPI.", "$35.750"),
        Item(5, "Disco SSD 1TB", "Velocidad de carga ultrarrápida.", "$79.990")
    )

    suspend fun getAll(): List<Item> {
        delay(500)
        return sampleItems
    }


    fun getById(id: Int): Item? = sampleItems.find { it.id == id }
}